export const environment = {
  production: true,

  firebaseConfig: {
    apiKey: 'AIzaSyA6MrUilTpZk3c9h1OG4ih1RpbC8bHJWnc',
    authDomain: 'fanderful-117.firebaseapp.com',
    projectId: 'fanderful-117',
    storageBucket: 'fanderful-117.appspot.com',
    messagingSenderId: '647666496063',
    appId: '1:647666496063:web:00254ac44a81e2cd747e8a',
    measurementId: 'G-2J729BKVPW'
  }
};
